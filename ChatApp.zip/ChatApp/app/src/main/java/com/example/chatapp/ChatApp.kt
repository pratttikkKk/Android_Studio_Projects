package com.example.chatapp

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.chatapp.ui.AuthScreen
import com.example.chatapp.ui.ChatScreen
import com.example.chatapp.ui.CallScreen

@Composable
fun ChatApp() {
    val navController = rememberNavController()
    NavHost(navController, startDestination = "auth") {
        composable("auth") {
            AuthScreen(onSuccess = { navController.navigate("chat") })
        }
        composable("chat") {
            ChatScreen(onCallClick = { room ->
                navController.navigate("videoCall/$room")
            })
        }
        composable("videoCall/{room}") { backStack ->
            val room = backStack.arguments?.getString("room") ?: "room1"
            CallScreen(room)
        }
    }
}
