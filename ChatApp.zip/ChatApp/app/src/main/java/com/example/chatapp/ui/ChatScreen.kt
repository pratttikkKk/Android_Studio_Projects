package com.example.chatapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

@Composable
fun ChatScreen(onCallClick: (room: String) -> Unit) {
    val db = FirebaseFirestore.getInstance()
    var message by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<String>() }

    // Fetch messages (simple)
    LaunchedEffect(Unit) {
        db.collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, _ ->
                messages.clear()
                snapshot?.forEach { doc ->
                    doc.getString("text")?.let { messages.add(it) }
                }
            }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(messages.size) { index ->
                Text(text = messages[index])
            }
        }
        Row {
            TextField(
                value = message,
                onValueChange = { message = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Enter message") }
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (message.isNotBlank()) {
                    db.collection("messages").add(
                        mapOf(
                            "text" to message,
                            "timestamp" to System.currentTimeMillis()
                        )
                    )
                    message = ""
                }
            }) {
                Text("Send")
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { onCallClick("room1") }) {
            Text("Start Call")
        }
    }
}
