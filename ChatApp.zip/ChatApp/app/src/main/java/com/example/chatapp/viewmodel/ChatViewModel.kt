package com.example.chatapp.viewmodel

import android.util.Base64
import androidx.lifecycle.ViewModel
import com.example.chatapp.model.ChatMessage
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.*

class ChatViewModel : ViewModel() {
    private val db = FirebaseDatabase.getInstance().getReference("chats")
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages = _messages.asStateFlow()

    init {
        db.orderByChild("timestamp").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = snapshot.children.mapNotNull {
                    it.getValue(ChatMessage::class.java)
                }
                _messages.value = list
            }
            override fun onCancelled(err: DatabaseError) {}
        })
    }

    fun sendMessage(text: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val enc = Base64.encodeToString(text.toByteArray(), Base64.NO_WRAP)
        val msg = ChatMessage(UUID.randomUUID().toString(), uid, enc, System.currentTimeMillis())
        db.child(msg.id).setValue(msg)
    }

    fun deleteMessage(id: String) {
        db.child(id).removeValue()
    }
}
