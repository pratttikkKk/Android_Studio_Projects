package com.example.chatapp.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp // ✅ Add this line
import com.google.firebase.auth.FirebaseAuth

@Composable
fun AuthScreen(onSuccess: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val ctx = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(email, { email = it }, label = { Text("Email") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            pass,
            { pass = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation()
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass)
                .addOnSuccessListener { onSuccess() }
                .addOnFailureListener {
                    FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass)
                        .addOnSuccessListener { onSuccess() }
                        .addOnFailureListener {
                            Toast.makeText(ctx, "Auth Error", Toast.LENGTH_SHORT).show()
                        }
                }
        }) {
            Text("Login / Register")
        }
    }
}
