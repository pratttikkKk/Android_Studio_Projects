// Root project build.gradle.kts
// You can leave this EMPTY or like below
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // NO NEED for classpath() entries anymore when using pluginManagement in settings.gradle.kts
    }
}
